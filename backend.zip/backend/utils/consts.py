
# ---------------- DATE TIME -----------------#
RESPONSE_DATE_FORMAT: str = "%d-%m-%Y"
RESPONSE_DATE_FORMAT_REG = r'^\d{2}-\d{2}-\d{4}$'

# ---------------- RESPONSE DATA -----------------#
SUCCESS = "Success"
SOMETHING_WENT_WRONG = "Something went wrong"
